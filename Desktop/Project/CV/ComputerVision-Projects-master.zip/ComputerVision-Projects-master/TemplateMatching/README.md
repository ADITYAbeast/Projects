# Template Matching

### Some Results


Template 1

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/TemplateMatching/Example%20-%20Template%201.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/TemplateMatching/Example%20-%20Template%201.png" width="600" height="400" />

Matched with original image 1

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/TemplateMatching/Example%20-%20Matched%201.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/TemplateMatching/Example%20-%20Matched%201.png" width="600" height="400" />



Template 2

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/TemplateMatching/Example%20-%20Template%202.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/TemplateMatching/Example%20-%20Template%202.png" width="600" height="400" />

Matched with original image 2

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/TemplateMatching/Example%20-%20Matched%202.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/TemplateMatching/Example%20-%20Matched%202.png" width="600" height="400" />

