# Face and Eye Detection

### Some Results

Example 1

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FaceEyeDetection/results%20-%201.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FaceEyeDetection/results%20-%201.png" width="600" height="400" />


Example 2

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FaceEyeDetection/results%20-%202.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVisonProjects/blob/master/FaceEyeDetection/results%20-%202.png" width="600" height="400" />
